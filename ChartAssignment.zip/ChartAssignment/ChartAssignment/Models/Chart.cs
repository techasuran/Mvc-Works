﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ChartAssignment.Models
{
    public class Chart
    {
        public string MyDate { get; set; }
        public string Microsft { get; set; }
        public string Apple { get; set; }


    }
}